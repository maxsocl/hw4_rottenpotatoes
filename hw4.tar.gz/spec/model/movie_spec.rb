require "spec_helper"

describe Movie do
  describe "it should find a list of movie by director"
end